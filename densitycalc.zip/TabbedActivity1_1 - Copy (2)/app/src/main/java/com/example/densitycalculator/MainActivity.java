package com.example.densitycalculator;

import android.annotation.SuppressLint;
import android.os.Build;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
//import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar2;
    TabLayout tabLayout;
    ViewPager viewPager;
    PagerAdapter pageAdapter;
    TabItem getDensity;
    TabItem getMass;
    TabItem getVolume;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        toolbar2 = findViewById(R.id.toolbar);
        toolbar2.setTitle(getResources().getString(R.string.app_name));
        setSupportActionBar(toolbar2);
        getSupportActionBar().setTitle("");

        tabLayout = findViewById(R.id.tabLayout);
        getDensity = findViewById(R.id.getDensity);
        getMass = findViewById(R.id.getMass);
        getVolume = findViewById(R.id.getVolume);
        viewPager = findViewById(R.id.viewPager);
        final TextView rimpidoText = findViewById(R.id.textView5);

        pageAdapter = new PageAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(pageAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener(){
            @SuppressLint("ResourceAsColor")
            @Override
            public void onTabSelected(TabLayout.Tab tab){
                viewPager.setCurrentItem(tab.getPosition());
                if (tab.getPosition() == 0){
                    toolbar2.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                    //viewPager.setBackgroundColor(R.color.colorAccent);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                        getWindow().setNavigationBarColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                        rimpidoText.setTextColor(getResources().getColor(R.color.colorPrimary));
                    }
                }else if (tab.getPosition() == 1){
                    toolbar2.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                    //viewPager.setBackgroundColor(R.color.rimpidoCoral);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoColor));
                        getWindow().setNavigationBarColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoColor));
                        rimpidoText.setTextColor(getResources().getColor(R.color.rimpidoColor));
                    }
                }else if (tab.getPosition() == 2){
                    toolbar2.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoDeepBlack));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoRed));
                        getWindow().setNavigationBarColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoRed));
                        rimpidoText.setTextColor(getResources().getColor(R.color.rimpidoRed));
                    }
                }else {
                    toolbar2.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoLight));
                    tabLayout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.rimpidoLight));
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
                        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.colorAccent));
                        getWindow().setNavigationBarColor(ContextCompat.getColor(MainActivity.this, R.color.colorPrimaryDark));
                    }
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab)
            {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab)
            {

            }

        });
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
    }

}
