package com.example.densitycalculator;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class MassFragment extends Fragment {
    private Button valueCalculateMass, valueClear, btnConvert;
    Button openLinkAboutUs;
    EditText txtMass, txtVolume2, txtDensity;
    String unitSelectorDensity, unitSelectorMass;
    String selectedUnitToConvert;
    Double answerOfVolume, convertedAnswer;
    List<String> listofUnitsforMass;
    Double[] convertedanswerList = new Double[8];

    public MassFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setHasOptionsMenu(true);
        return inflater.inflate(R.layout.fragment_mass, container, false);
    }

    public void setSpinnerMass(View view){
        Spinner spinnerMassUnit = view.findViewById(R.id.spinnerMassUnit);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.volumeUnits, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMassUnit.setAdapter(adapter);

        spinnerMassUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                unitSelectorMass = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void setSpinnerDensity(View view){
        final Spinner densityUnit = view.findViewById(R.id.spinnerDensityUnit);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.densityUnits, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        densityUnit.setAdapter(adapter);

        densityUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                unitSelectorDensity = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    public void dialogBoxConvert(View view){
        listofUnitsforMass = new ArrayList<>();

        listofUnitsforMass.add("g");
        listofUnitsforMass.add("kg");
        listofUnitsforMass.add("ct");
        listofUnitsforMass.add("oz");
        listofUnitsforMass.add("lb");
        listofUnitsforMass.add("ton");
        listofUnitsforMass.add("mg");

        final CharSequence[] listofUnits = listofUnitsforMass.toArray(new String[listofUnitsforMass.size()]);
        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        btnConvert = view.findViewById(R.id.btnConvert);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogBuilder.setTitle("Choose Density Unit");
                dialogBuilder.setItems(listofUnits, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectedUnitToConvert = listofUnits[which].toString();
                        Toast.makeText(getActivity(), "You Selected: " + selectedUnitToConvert + " .", Toast.LENGTH_SHORT).show();

                        if (selectedUnitToConvert.equals("g")){
                            convertedAnswer = answerOfVolume;
                            convertedanswerList[0] = convertedAnswer;
                        }else if (selectedUnitToConvert.equals("kg")){
                            convertedAnswer = answerOfVolume/1000;
                            convertedanswerList[1] = convertedAnswer;
                        }else if (selectedUnitToConvert.equals("ct")){
                            convertedAnswer = answerOfVolume*5;
                            convertedanswerList[2] = convertedAnswer;
                        }else if (selectedUnitToConvert.equals("oz")){
                            convertedAnswer = answerOfVolume/28.35;
                            convertedanswerList[3] = convertedAnswer;
                        }else if (selectedUnitToConvert.equals("lb")){
                            convertedAnswer = answerOfVolume/453.592;
                            convertedanswerList[4] = convertedAnswer;
                        }else if (selectedUnitToConvert.equals("ton")){
                            convertedAnswer = answerOfVolume/907184.74;
                            convertedanswerList[5] = convertedAnswer;
                        }else if (selectedUnitToConvert.equals("mg")){
                            convertedAnswer = answerOfVolume*1000;
                            convertedanswerList[6] = convertedAnswer;
                        }



                            txtVolume2.setText("" + convertedAnswer + " " + selectedUnitToConvert);


                       // txtVolume2.setText("" + String.format("%.2f", convertedAnswer) + " " + selectedUnitToConvert);

                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();

            }
        });

    }


    public Double convertoG(int casegiven, Double answer){
        Double finalAnswer=0.0;
        if (casegiven == 1){
            finalAnswer = answer*1000;//*1000000;
        }else if (casegiven == 2){
            finalAnswer = answer;
        }else if (casegiven == 3){
            finalAnswer = answer;
        }else if (casegiven == 4){
            finalAnswer = answer*453.592;
        }else if (casegiven == 5){
            finalAnswer = answer*453.592;
        }else if (casegiven == 6){
            finalAnswer = answer*453.592;
        }else if (casegiven == 7){
            finalAnswer = answer*453.592;
        }else if (casegiven == 8){
            finalAnswer = answer*28.35;
        }else if (casegiven == 9){
            finalAnswer = answer*28.35;
        }else if (casegiven == 10){
            finalAnswer = answer*28.35;
        }else if (casegiven == 11){
            finalAnswer = answer*907184.74;
        }

        answerOfVolume = finalAnswer;

        return finalAnswer;
    }

    public void openAboutUs(View view){
        openLinkAboutUs = view.findViewById(R.id.btnAboutUs);

        openLinkAboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("http://www.rimpido.com/en/contact.html")));
            }
        });
    }

     @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        setSpinnerDensity(view);
        setSpinnerMass(view);
        clearButton(view);
        dialogBoxConvert(view);
        openAboutUs(view);

        txtVolume2 = view.findViewById(R.id.answerDensity); //txtVolume2 is actually txtMass, but for some reasons whenever I try to rename the variable it produces an error
          valueCalculateMass = view.findViewById(R.id.btnCalculateMass);

        txtVolume2.setInputType(InputType.TYPE_NULL);

        txtVolume2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.onTouchEvent(event);

                InputMethodManager imm = (InputMethodManager)v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);

                if (imm!= null){
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }

                return true;

            }
        });

         valueCalculateMass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try
                {
                txtMass = view.findViewById(R.id.txtVolume);//actually TxtVolume, not Mass.
                txtDensity = view.findViewById(R.id.txtDensity);
                Double mass = Double.parseDouble(txtMass.getText().toString());
                Double density = Double.parseDouble(txtDensity.getText().toString());
                Double convertedMass=0.0, convertedDensity=0.0;
                Double answer;
                int caseGiven=0;

                /*first row for mass conversion*/
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/61023.744;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass*16.387;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/61.024;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/1728;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/46656;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/231;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/1728;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("in3")){
                    convertedMass=mass/231;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("in3")){ //short usa tons
                    convertedMass=mass/46656;
                    convertedDensity=density;
                    caseGiven=11;
                }
                /*first row for mass conversion*/
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass/1.308;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*764554.858;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*764.555;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*46656;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*27;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*201.974;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*46656;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*27;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("yd3")){
                    convertedMass=mass*201.974;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("yd3")){ //short usa tons
                    convertedMass=mass;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /*THIRD row for mass conversion*/
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass/35.315;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*28316.847;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*28.317;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*1728;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass/27;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*7.481;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*1728;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass*7.481;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("ft3")){
                    convertedMass=mass/27;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /*FOURTH row for mass conversion*/
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*1000000;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*1000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*61023.744;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*35.315;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*1.308;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*264.172;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass/61023.744;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*35.315;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*264.172;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("m3")){
                    convertedMass=mass*1.308;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /*FIFTH row for mass conversion*/
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/1000000000;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/1000;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/1000000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/16387.064;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/2.832e+7;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/7.646e+8;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/3.785e+6;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/16387.064;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/2.832e+7;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/3.785e+6;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/7.646e+8;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /*FIFTH row for mass conversion
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/1000000000;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/1000;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/1000000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/16387.064;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass*2.8320000000;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass*650000000;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass*3.785000000;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/16387.064;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/2.8320000000;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/3.785000000;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("mm3")){
                    convertedMass=mass/7.6500000000;
                    convertedDensity=density;
                    caseGiven=11;
                }*/

                /*SIXTH row for mass conversion*/
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/1000000;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/1000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/16.387;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/28316.847;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/764554.858;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/3785.412;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/16.387;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/28316.847;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/3785.412;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("cm3")){
                    convertedMass=mass/764554.858;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /*EIGHT row for mass conversion. Tried to do nested conversion to lessen the number of digits to multiply. */
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("mi3")){
                    //Double massUsed = mass*4.168e+9;
                    convertedMass=mass*4.168e+9;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("mi3")){
                    convertedMass=mass*4.168e+15;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("mi3")){
                    double massUsed = mass*4.168;
                    double value2 =massUsed*1000000;
                    convertedMass=value2*1000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("mi3")){
                    double massUsed = mass*4.168;
                    double value2=massUsed*1000000;
                    convertedMass=value2*61023.744;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("mi3")){
                    double massUsed = mass*4.168;
                    double value2=massUsed*1000000;
                    convertedMass=value2*35.315;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("mi3")){
                    double massUsed = mass*4.168;
                    double value2=massUsed*1000000;
                    convertedMass=value2*1.308;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("mi3")){
                    convertedMass=mass*101.e+12;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("mi3")){
                    double massUsed = mass*4.168;
                    double value2=massUsed*1000000;
                    convertedMass=value2/61023.744;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("mi3")){
                    //double massUsed = mass*4.168;
                   // double value2=massUsed*1000000;
                    convertedMass=mass*1.472e+11;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("mi3")){
                    //double massUsed = mass*4.168;
                   // double value2=massUsed*1000000;
                    convertedMass=mass*1.101e+12;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("mi3")){ //short tons
                   // double massUsed = mass*4.168;
                   // double value2=massUsed*1000000;
                    convertedMass=mass*5.452e+9;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /*EIGHT row for mass conversion. km3 is not yet final. */
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("km3")){
                    convertedMass=mass*100000000;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*1000000;// change this one.
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*1000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*61023.744;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*35.315;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*1.308;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*264.172;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*61023.744;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("km3")){
                    //double massUsed = mass*1000000000;
                    convertedMass=mass*3.531e+10;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*264.172;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("km3")){
                    double massUsed = mass*1000000000;
                    convertedMass=massUsed*1.308;
                    convertedDensity=density;
                    caseGiven=11;
                }


                /* NINTH row for mass conversion. */
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/1000;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("L")){
                    double massUsed = mass/1000;
                    convertedMass=massUsed*1000000;
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("L")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass*61.024;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/28.317;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/764.555;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/3.785;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass*61.024;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/28.317;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/3.785;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("L")){
                    convertedMass=mass/764.555;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /* TENTH row for mass conversion. mL */
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/1000000;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass*1;// change this one.
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/1000;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/16.387;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/28316.847;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/764554.858;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/3785.412;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/16.387;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/28316.847;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/3785.412;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("mL")){
                    convertedMass=mass/764554.858;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /* TENTH row for mass conversion. qt */
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/1056.688;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass*946.353;// change this one.
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/1.057;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass*57.75;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/29.922;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/807.896;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/4;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass*57.75;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/29.922;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/4;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("qt")){
                    convertedMass=mass/807.896;
                    convertedDensity=density;
                    caseGiven=11;
                }

                /* TENTH row for mass conversion. GAL */
                if (unitSelectorDensity.equals("kg/m3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass/264.172;
                    convertedDensity=density;
                    caseGiven=1;
                }else if (unitSelectorDensity.equals("g/cm3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass*3785.412;// change this one.
                    convertedDensity=density;
                    caseGiven=2;
                }else if (unitSelectorDensity.equals("g/L")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass*3.785;
                    convertedDensity=density;
                    caseGiven=3;
                }else if (unitSelectorDensity.equals("lb/in3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass*231;
                    convertedDensity=density;
                    caseGiven=4;
                }else if (unitSelectorDensity.equals("lb/ft3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass/7.481;
                    convertedDensity=density;
                    caseGiven=5;
                }else if (unitSelectorDensity.equals("lb/yd3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass/201.974;
                    convertedDensity=density;
                    caseGiven=6;
                }else if (unitSelectorDensity.equals("lb/gal")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=7;
                }else if (unitSelectorDensity.equals("oz/in3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass*231;
                    convertedDensity=density;
                    caseGiven=8;
                }else if (unitSelectorDensity.equals("oz/ft3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass/7.481;
                    convertedDensity=density;
                    caseGiven=9;
                }else if (unitSelectorDensity.equals("oz/gal")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass*1;
                    convertedDensity=density;
                    caseGiven=10;
                }else if (unitSelectorDensity.equals("ton/yd3")&&unitSelectorMass.equals("gal")){
                    convertedMass=mass/201.974;
                    convertedDensity=density;
                    caseGiven=11;
                }

                //COMPUTE ANSWERS
                answer = (convertedMass*convertedDensity);


                List<Double> answerListArray = Arrays.asList(convertedanswerList);

                if (answerListArray.contains(answer)){
                    if (convertedanswerList[5] == answer) {
                        //do nothing
                    }else if (convertedanswerList[0] != answer){
                        convertedanswerList[5] = answer;
                    }
                }else if (!answerListArray.contains(answer)){
                    convertedanswerList[5] = answer;
                }


                        if (answer%1 == 0) //checks if the Mass has decimal points
                        {
                            txtVolume2.setText("" + convertoG(caseGiven, answer) + " g");


                            ScrollView scr = view.findViewById(R.id.scrMass);
                            scr.fullScroll(ScrollView.FOCUS_UP);

                            AlertDialog.Builder showAnswer = new AlertDialog.Builder(getActivity());
                            showAnswer.setTitle("Answer: ").setMessage("Mass is: " + convertoG(caseGiven, answer) + " g").setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                            AlertDialog alert = showAnswer.create();
                            alert.show();
                        }else if (answer%1 != 0){ // checks if the Mass has a remainder
                            txtVolume2.setText("" + String.format("%.7f", convertoG(caseGiven, answer)) + " g");


                            ScrollView scr = view.findViewById(R.id.scrMass);
                            scr.fullScroll(ScrollView.FOCUS_UP);

                            AlertDialog.Builder showAnswer = new AlertDialog.Builder(getActivity());
                            showAnswer.setTitle("Answer: ").setMessage("Mass is: " +  String.format("%.7f", convertoG(caseGiven, answer)) + " g").setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                            AlertDialog alert = showAnswer.create();
                            alert.show();
                        }




                //txtVolume2.setText("" + String.format("%.2f", convertoG(caseGiven, answer)) + " g");
                }catch (Exception e){
                    Toast.makeText(getActivity(), "Please input values for Density and Volume.", Toast.LENGTH_SHORT);
                }
            }
        });
    }

    public void clearButton(View view){
        valueClear = view.findViewById(R.id.btnClear);

        valueClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    txtMass.setText("");
                    txtVolume2.setText("");
                    txtDensity.setText("");
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "Error!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.densityselected, menu);
    }
}
